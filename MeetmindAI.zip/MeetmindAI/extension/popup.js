let currentMode = 'internal';
let trackingInterval = null;
let isTracking = false;
let secondsElapsed = 0;

document.addEventListener('DOMContentLoaded', () => {
    const internalBtn = document.getElementById('internal-btn');
    const auditBtn = document.getElementById('audit-btn');
    const statusText = document.getElementById('status-text');
    const mainActionBtn = document.getElementById('main-action-btn');
    const actionBtnText = document.getElementById('action-btn-text');
    const timerDisplay = document.querySelector('.runtime-counter');

    function updateTimerUI() {
        const mins = Math.floor(secondsElapsed / 60);
        const secs = secondsElapsed % 60;
        if (timerDisplay) {
            timerDisplay.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        }
    }

    function switchMode(selectedMode) {
        if (isTracking) return;
        currentMode = selectedMode;
        if (currentMode === 'internal') {
            if (internalBtn) internalBtn.classList.add('active');
            if (auditBtn) auditBtn.classList.remove('active');
            if (statusText) statusText.textContent = "Internal Performance Log";
            if (actionBtnText) actionBtnText.textContent = "Compile Workspace Analytics";
        } else if (currentMode === 'audit') {
            if (auditBtn) auditBtn.classList.add('active');
            if (internalBtn) internalBtn.classList.remove('active');
            if (statusText) statusText.textContent = "Audited Verification Record";
            if (actionBtnText) actionBtnText.textContent = "Generate Verified Alignment Records";
        }
    }

    if (internalBtn) internalBtn.addEventListener('click', () => switchMode('internal'));
    if (auditBtn) auditBtn.addEventListener('click', () => switchMode('audit'));

    if (mainActionBtn) {
        mainActionBtn.addEventListener('click', () => {
            if (!isTracking) {
                isTracking = true;
                secondsElapsed = 0;
                updateTimerUI();
                mainActionBtn.style.background = '#10B981';
                if (actionBtnText) actionBtnText.textContent = "Stop Tracking & Sync Vault";

                trackingInterval = setInterval(() => {
                    secondsElapsed++;
                    updateTimerUI();
                }, 1000);
            } else {
                isTracking = false;
                clearInterval(trackingInterval);
                mainActionBtn.style.background = '#dc2626';
                if (actionBtnText) {
                    actionBtnText.textContent = currentMode === 'internal' ? "Compile Workspace Analytics" : "Generate Verified Alignment Records";
                }

                const payload = {
                    id: Math.random().toString(36).substr(2, 9),
                    tracking_mode: currentMode,
                    duration_seconds: secondsElapsed,
                    speaking_time_ratios: { "host": 0.65, "team": 0.35 },
                    interruption_count: Math.floor(secondsElapsed / 5),
                    collaboration_health_score: 92,
                    executive_summary: currentMode === 'audit' ? "Approved structural system transition into serverless architecture modules." : null,
                };

                // 🚀 Send the data straight to the local browser storage channel
                localStorage.setItem('LATEST_MEETMIND_SESSION', JSON.stringify(payload));
                
                alert(`Local Session Sync Complete! Let's check the dashboard tab now.`);
                secondsElapsed = 0;
                updateTimerUI();
            }
        });
    }
});